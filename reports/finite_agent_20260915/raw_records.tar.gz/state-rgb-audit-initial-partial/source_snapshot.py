"""Audit all saved physical states and bind every prediction to its RGB clip."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import tarfile

import numpy as np

base = Path('/root/autodl-tmp/actionstream-agent-20260915')
work = base / 'finite-agent-v1'
sys.path.insert(0, str(base / 'finite-agent-source/scripts/engineering'))
from completion_controls import make_env
from actionstream.completion_labels import StableTruth, simulator_facts
from actionstream.llm_vla.finite_native import save, digest

if json.loads((work / 'run_receipt.json').read_text())['status'] != 'COMPLETED':
    raise ValueError('Do not audit an unfinished run')
out = work / 'state-rgb-audit'
out.mkdir(exist_ok=False)
(out / 'source_snapshot.py').write_bytes(Path(__file__).read_bytes())
env = make_env(argparse.Namespace(base=base), out)
records = []
try:
    episodes = json.loads((work / 'execution_progress.json').read_text())
    for entry in episodes:
        directory = work / 'run' / entry['id']
        env.reset()
        env.reset_from_xml_string((directory / 'environment.xml').read_text())
        facts = json.loads((directory / 'private_truth.json').read_text())
        events = [json.loads(line) for line in (directory / 'runtime.jsonl').read_text().splitlines()]
        checks = [row for row in events if row['event'] == 'verification' and row['history_ready']]
        labels, changed = [], []
        truth = StableTruth()
        path = directory / 'trajectory.npz'
        with np.load(path, allow_pickle=False) as data:
            assert len(data['states']) == len(data['rgb']) == len(facts)
            for row in checks:
                c = row['control']
                clip = data['rgb'][np.array([c-10, c-5, c])]
                assert hashlib.sha256(clip.tobytes()).hexdigest() == row['clip_sha256']
            for control, state in enumerate(data['states']):
                env.set_state(state)
                env.sim.forward()
                f = simulator_facts(env)
                f['strict_complete'] = truth.update(control, f)
                labels.append(f)
                fields = [k for k in ('inside', 'finger_contact', 'basket_contact', 'strict_complete') if f[k] != facts[control][k]]
                if fields:
                    changed.append(dict(control=control, fields=fields, recorded=facts[control], restored=f))
        save(out / (entry['id'] + '.json'), labels)
        records.append(dict(id=entry['id'], seed=entry['seed'], states=len(facts), rgb_clips_checked=len(checks), image_state_sha256=digest(path), changed=changed))
        print(json.dumps(dict(id=entry['id'], states=len(facts), strict_changes=sum('strict_complete' in r['fields'] for r in changed))), flush=True)
finally:
    env.close()
save(out / 'summary.json', dict(records=records, source_sha256=digest(__file__), freeze_sha256=digest(work / 'freeze.json')))
external = {}
for p in work.rglob('*'):
    if p.is_file() and p.suffix in ('.npz', '.pt'):
        external[p.relative_to(work).as_posix()] = dict(bytes=p.stat().st_size, sha256=digest(p))
save(work / 'external_blobs.json', external)
files = [p for p in work.rglob('*') if p.is_file() and p.suffix in ('.json', '.jsonl', '.py', '.xml', '.toml', '.lock')]
archive = base / 'finite-agent-evidence.tgz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in sorted(files):
        tar.add(path, arcname=path.relative_to(work).as_posix())
manifest = dict(archive_sha256=digest(archive), files={p.relative_to(work).as_posix():digest(p) for p in files}, implementation_commit='4b653fe180e3f45fb48d42b52965c5dbad33a3ee')
save(base / 'finite-agent-evidence-manifest.json', manifest)
print(json.dumps(dict(status='FINITE_AGENT_EVIDENCE_READY', archive_bytes=archive.stat().st_size, states=sum(r['states'] for r in records), clips=sum(r['rgb_clips_checked'] for r in records), changed_strict=sum('strict_complete' in c['fields'] for r in records for c in r['changed']))), flush=True)
