import hashlib,json,pathlib,tarfile,time
root=pathlib.Path('/root/autodl-tmp/actionstream-delivery-20260915')
run=root/'async-acceptance-v2'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
for phase in ('normal','recovery'):
 assert (root/f'async-acceptance-v2-{phase}.exit').read_text().strip()=='0'
 assert read(run/phase/'result.json')['requested']==10
audit=read(run/'state-rgb-audit/summary.json')
assert audit['episodes']==20
selected=['async-acceptance-v2','async-acceptance-v1','async-acceptance-v1-development.log','async-acceptance-v1-development.exit','async-acceptance-v2-development.log','async-acceptance-v2-development.exit','async-acceptance-v2-normal.log','async-acceptance-v2-normal.exit','async-acceptance-v2-recovery.log','async-acceptance-v2-recovery.exit','worker-diagnostic','worker-diagnostic.log','diagnose_worker.py','run_async.sh','audit_async_agent.py','current-delivery.json','source-4570e7c-hashes.json']
paths=[]
selected += ['async-state-audit.log','async-state-audit.exit','package_async_final.py']
for name in selected:
 p=root/name
 paths.extend([p] if p.is_file() else sorted(q for q in p.rglob('*') if q.is_file()))
files={str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in paths}
manifest=dict(files=files,source_commit=read(run/'freeze.json')['source_commit'],packaged_unix=time.time(),normal=read(run/'normal/result.json')['status'],recovery=read(run/'recovery/result.json')['status'],state_audit=audit['status'])
(root/'async-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
paths.append(root/'async-files.json')
full=root/'async-acceptance-v2-full.tar.gz'
with tarfile.open(full,'w:gz',compresslevel=1) as t:
 for p in paths:t.add(p,arcname=p.relative_to(root).as_posix())
compact=root/'async-acceptance-v2-records.tar.gz'
with tarfile.open(compact,'w:gz',compresslevel=6) as t:
 for p in paths:
  if p.suffix not in ('.npz','.pt'):t.add(p,arcname=p.relative_to(root).as_posix())
summary=dict(status='PACKAGED',full=dict(name=full.name,bytes=full.stat().st_size,sha256=sha(full)),compact=dict(name=compact.name,bytes=compact.stat().st_size,sha256=sha(compact)),files=len(files))
(root/'async-archives.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
