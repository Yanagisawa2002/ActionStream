#!/usr/bin/env bash
set -eu
STORE=/root/autodl-tmp/actionstream-delivery-20260915
PHASE="$1"
RUN="$2"
COMMIT="$3"
cd "$STORE/source"
export PYTHONPATH=
export LD_LIBRARY_PATH="$STORE/native-sysroot/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
export MUJOCO_GL=egl PYOPENGL_PLATFORM=egl HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export HF_HOME="$STORE/offline-$RUN-$PHASE"
set +e
.venv/bin/python scripts/engineering/evaluate_async_agent.py "$PHASE" --store "$STORE" --output "$STORE/$RUN" --source-commit "$COMMIT" --delivery-receipt "$STORE/current-delivery.json"
STATUS="$?"
printf '%s\n' "$STATUS" > "$STORE/$RUN-$PHASE.exit"
exit "$STATUS"
