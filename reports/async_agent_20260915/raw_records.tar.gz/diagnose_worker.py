import os,pathlib,time,threading,faulthandler
S=pathlib.Path('/root/autodl-tmp/actionstream-delivery-20260915')
os.environ['MUJOCO_GL']=os.environ['PYOPENGL_PLATFORM']='egl'
from actionstream.libero_config import ensure_isolated_libero_config
ensure_isolated_libero_config(S/'worker-diagnostic-config',assets_dir=S/'libero-assets')
from actionstream.llm_vla.agent_cli import backend_factory
from actionstream.llm_vla.async_native import AsyncSimulationPort
from actionstream.llm_vla.temporal_completion import TemporalPredictor
from actionstream.llm_vla.finite_agent import CHECKPOINT_SHA256
import torch
torch.set_num_threads(8)
backend=backend_factory(S/'assets',2026092000)
output=S/'worker-diagnostic'; output.mkdir(exist_ok=False)
port=AsyncSimulationPort(backend,2026092000,output)
observation=port.start('worker-diagnostic',0)
predictor=TemporalPredictor(S/'frozen.pt',CHECKPOINT_SHA256)
t=time.monotonic();port.warmup(observation,'put the tomato sauce in the basket',predictor)
print('main warmup seconds',time.monotonic()-t,flush=True)
def run():
 print('worker thread counts',torch.get_num_threads(),torch.get_num_interop_threads(),flush=True)
 t=time.monotonic();port.reset_inference();print('reset seconds',time.monotonic()-t,flush=True)
 for index in range(2):
  t=time.monotonic();port.infer(observation,'put the tomato sauce in the basket');print('worker inference',index,time.monotonic()-t,flush=True)
faulthandler.dump_traceback_later(5,repeat=True)
worker=threading.Thread(target=run);worker.start();worker.join()
faulthandler.cancel_dump_traceback_later()
port.close();backend.close()
